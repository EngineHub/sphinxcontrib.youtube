Python 3 fixed package of of https://github.com/shomah4a/sphinxcontrib.youtube

Install:

```shell
pip3 install enginehub.sphinx_youtube
```
